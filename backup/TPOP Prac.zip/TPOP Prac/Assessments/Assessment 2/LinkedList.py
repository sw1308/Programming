## Supervisor Name:

class SortedLinkedList:
    
    #---------------Inner Class: Node-----------------------------
    class Node:

        def __init__(self, element):
            self.datum = element   ## should contains an int value
            self.next = None       ## contains a Node object

        def __repr__(self):
            return str(self.datum)
        
    #---------------End Inner Class: Node-----------------------------

        
    def __init__(self):
        self.head = None    ## contains a Node object
        self._size = 0

    def __repr__(self):
        rep = '<SortedLinkedList: (size = ' + str(self._size) + '), elements: '
        if self.head != None:
            currentNode = self.head 
            while currentNode != None:
                rep +=  str(currentNode.datum) + ', '
                currentNode = currentNode.next

        rep += '>'
        return rep
    
        
    def isempty(self):
        return (self.head is None) ## could use size == 0 as well

    def size(self):
        return self._size


    ##############################################
    ##
    ##                 QUESTION 3
    ##
    ##############################################

    ## WRITE CODE HERE
    ## Watch your indentation










    ##############################################
    ##
    ##                 QUESTION 4
    ##
    ##############################################

    ## WRITE CODE HERE
    ## Watch your indentation






#######################################################
##
##                TESTS
##
#######################################################
        
## WRITE TEST CODE HERE
## Watch your indentation






























































