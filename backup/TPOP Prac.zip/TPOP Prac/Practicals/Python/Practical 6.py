class LinkedQueue:
	""" Queue implementation using a Linked-List for storage"""

	#---------------Inner Class: Node-----------------------------
	class Node:
		""" Non-public class for storing a singly-linked node."""

		def __init__(self, datum, nextNode):
			self.datum = datum   ## any type of data to be stored in the queue
			self.next = nextNode ## a Node object
	#---------------End Inner Class: Node-----------------------------


	def __init__(self):
		"""
		Create and empty queue.
		"""
		self.head = None ## a Node object
		self.tail = None ## a Node object
		self.size = 0


	def enQueue(self, x):
		newNode = LinkedQueue.Node(x, None) ## create a new node
	
		if self.size == 0: ## empty list
			self.head = newNode
			self.tail = newNode
		
		else:        
			tailNode = self.tail
			tailNode.next = newNode
			self.tail = newNode
		
		self.size += 1

	def printQueue(self):
		currentNode = self.head
		print "queue: <",
		
		while currentNode is not None:
			if currentNode.next is not None:
				print str(currentNode.datum) + ",",
			else:
				print currentNode.datum,
				
			currentNode = currentNode.next ## moving along the queue
		
		print ">"

	def size(self):
		return self.size

	def dequeue(self):
		head = self.head
		self.head = head.next
		return head.datum

	def concat_queues(self, queue2):
		self.tail.next = queue2.head

	def reverse(self):
		reverseQueue = LinkedQueue()
		queueArray = []
		currentNode = self.head
		i = 0
		
		while currentNode is not None:
			queueArray.append(currentNode.datum)
			i += 1
			currentNode = currentNode.next
		
		queueArray.reverse()

		for i in xrange(len(queueArray)):
			reverseQueue.enQueue(queueArray[i - 1])
		
		return reverseQueue

## test

cinequeue = LinkedQueue()
reversequeue = LinkedQueue()
cinequeue.printQueue()

cinequeue.enQueue(1)
cinequeue.enQueue(2)
cinequeue.enQueue(3)
cinequeue.enQueue(4)
cinequeue.enQueue(5)

cinequeue.printQueue()

reversequeue = cinequeue.reverse()
cinequeue.enQueue(6)
cinequeue.concat_queues(reversequeue)

cinequeue.printQueue()
print cinequeue.dequeue()
cinequeue.printQueue()

raw_input()