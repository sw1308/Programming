a = "All"
b = "work"
c = "and"
d = "no"
e = "play"
f = "makes"
g = "Jack"
h = "a"
i = "dull"
j = "boy."

print a, b, c, d, e, f, g, h, i, j
raw_input()