###########################
# Question 1
#
# Write a function to return the sum of a list of numbers.
###########################

'''
def sumList(nums):
	total = 0
	
	for item in nums:
		total += item

	return total

size = int(raw_input("Enter size of the list of numbers: "))
numbers = []

for i in xrange(size):
	numbers.append(int(raw_input("Next number: ")))

print "Total: ", sumList(numbers)
raw_input()
'''

###########################
# Question 2
#
# Write a function that takes a list
# of numbers and returns a list of
# the same numbers squared.
###########################

'''
def squareEach(nums):
	squareList = []
	
	for item in nums:
		squareList.append(item*item)
	
	return squareList

size = int(raw_input("Enter size of the list of numbers: "))
numbers = []

for i in xrange(size):
	numbers.append(int(raw_input("Next number: ")))

print "Squares: ", squareEach(numbers)
raw_input()
'''

###########################
# Question 3
#
# Write a function that converts a
# string of numbers separated by a
# space into a list of numbers.
###########################

def toNumbers(strList):
	return strList.split()

inputString = raw_input("Enter a string of numbers separated by spaces: ")

print "List of numbers: ", toNumbers(inputString)
raw_input()