###########################
# Question 1
#
# Write a block of code that takes
# a string as an input and outputs
# the ascii value of each character
# in the string added together.
###########################

'''
input_string = raw_input("Enter a string: ")
total = 0

for letter in input_string:
	total = total + ord(letter)

print total
raw_input()
'''

###########################
# Question 2
#
# Write a block of code that takes a
# string as an input and outputs
# whether the string is a palindrome or not.
###########################

'''
input_string = raw_input("Enter a string: ").lower()
is_palindrome = False

if input_string == input_string[::-1]:
	is_palindrome = True

print "Palindrome? ", is_palindrome
raw_input()
'''

###########################
# Question 3
#
# Write a block of code that uses
# arrays to represent vectors and
# can perform two basic vector operations,
# addition and calculating scalar products.
###########################

'''
product = 1
size = 1
vector1 = []
vector2 = []
vectorResult = []

size = int(raw_input("Enter the dimension of the vectors: "))
product = int(raw_input("Enter the product for scalar calculations: "))

for i in xrange(size):
	vector1.append(int(raw_input("Enter the number in position "+ str(i) + ": ")))

for i in xrange(size):
	vector2.append(int(raw_input("Enter the number in position "+ str(i) + ": ")))

for i in xrange(size):
	vectorResult.append(0)

def add(vector1, vector2):
	for i in xrange(size):
		vectorResult[i] = vector1[i] + vector2[i]
	
	return vectorResult

def scalarProduct(vector1, product):
	for i in xrange(size):
		vectorResult[i] = vector1[i] * product
	
	return vectorResult

print "Scalar Product: ", scalarProduct(vector1, product)
print "Addition: ", add(vector1, vector2)
raw_input()
'''

###########################
# Question 4
#
# Write a block of code that prints
# a table of stone to kilogram conversions.
###########################

size = 0
stone = 0
pound = 0
kilogram = 0
line = "|stone/pound|"

size = int(raw_input("Enter the size of the table: "))

for i in xrange(size):
	line = line + "    " + str(pound) + "|"
	pound += 1

print line
line = ""

for i in xrange(size):
	line = "|          " + str(stone) + "|"
	pound = 0
	
	for j in xrange(size):
		kilogram = round(((stone * 6.35) + (pound * 0.45)), 1)
		if kilogram > 10:
			line = line + " " + str(kilogram) + "|"
		elif kilogram > 100:
			line = line + str(kilogram) + "|"
		else:
			line = line + "  " + str(kilogram) + "|"
		pound += 1

	stone += 1
	print line

raw_input()