class member:
	def __init__(self, firstName, surName, postCode):
		self.firstName = firstName
		self.surName = surName
		self.postCode = postCode
		self.itemList = []

	def getFirstName(self):
		return self.firstName
	
	def getSurName(self):
		return self.surName
	
	def getPostCode(self):
		return self.postCode
	
	def getItemList(self):
		return self.itemList
	
	def setFirstName(self, firstName):
		self.firstName = firstName
	
	def setSurName(self, surName):
		self.surName = surName
	
	def setPostCode(self, postCode):
		self.postCode = postCode
	
	def setItemList(self, itemList):
		self.itemList = itemList
	
	def __repr__(self):
		return "Name: " + self.firstName + " " + self.surName + "    |Postcode: " + self.postCode + "    |Rented Items: " + str(self.itemList)

class item:
	def __init__(self, title, author, mediaType):
		self.title = title
		self.author = author
		self.mediaType = mediaType
		self.status = False
		self.memberID = -1
	
	def getTitle(self):
		return self.title
	
	def getAuthor(self):
		return self.author
	
	def getMediaType(self):
		return self.mediaType
	
	def getStatus(self):
		return self.status
	
	def getMemberID(self):
		return self.memberID
	
	def setTitle(self, title):
		self.title = title
	
	def setAuthor(self, author):
		self.author = author
	
	def setMediaType(self, mediaType):
		self.mediaType = mediaType
	
	def setStatus(status):
		self.status = status
	
	def __repr__(self):
		if self.status == False:
			taken = "Not Taken"
		else:
			taken = "Taken"
		return "Title: " + self.title + "    |Author: " + self.author + "    |Media Type: " + self.mediaType + "    |Status: " + taken + "    |ID of Renter: " + str(self.memberID)

def addMember(memberID, newMember):
	memberLibrary[memberID] = newMember

def delMember(memberID):
	del memberLibrary[memberID]

def addItem(itemID, newItem):
	itemLibrary[itemID] = newItem

def delItem(itemID):
	del itemLibrary[itemID]

def rentItem(memberID, itemID):
	member = memberLibrary[memberID]
	item = itemLibrary[itemID]
	member.itemList.append(itemID)
	item.status = True
	item.memberID = memberID
	memberLibrary[memberID] = member
	itemLibrary[itemID] = item

def returnItem(memberID, itemID):
	member = memberLibrary[memberID]
	item = itemLibrary[itemID]
	member.itemList.remove(itemID)
	item.status = False
	item.memberID = -1
	memberLibrary[memberID] = member
	itemLibrary[itemID] = item

def printMembers():
	print "Members: ", memberLibrary

def printItems():
	print "Items: ", itemLibrary

memberLibrary = {}
itemLibrary = {}

member1 = member("Jack", "Butcher", "YO10 5ES")
member2 = member("James", "Hornsby", "YO10 5ES")
member3 = member("Liam", "Franks", "YO10 5ES")

item1 = item("Title 1", "Author 1", "CD")
item2 = item("Title 2", "Author 2", "DVD")
item3 = item("Title 3", "Author 3", "Book")

addMember(0, member1)
addMember(1, member2)
addMember(2, member3)

addItem(0, item1)
addItem(1, item2)
addItem(2, item3)