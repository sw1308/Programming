number = 0
greatest = 0

for i in xrange(0, 3):
	number = int(raw_input("Next Number: ")
	if number > greatest:
		greatest = number

print "Greatest: ", greatest
raw_input()