/*
 * Question 1
 *
 * There is no code for question 1 as the task was to rewrite some of the earlier questions in java.
 **/

/*
 * Question 2
 *
 * Write a program that takes several inputs and determines the BMR and number of chocolate bars
 * that it equates to.
 **/

/*
import java.util.Scanner;
import java.lang.Math;

public class Practical11 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int weight, height, age, gender;
		int chocolateBMR;
		
		System.out.print("Are you:\n(1) Male\n(2) Female\n\nSelection: ");
		gender = s.nextInt();
		
		System.out.print("\nEnter your weight in pounds: ");
		weight = s.nextInt();
		
		System.out.print("\nEnter your height in inches: ");
		height = s.nextInt();
		
		System.out.print("\nEnter your age in years: ");
		age = s.nextInt();
		
		if(gender == 1) {
			chocolateBMR = (int)Math.round((66 + (6.3*weight) + (12.9*height) - (6.8*age))/230);
		} else {
			chocolateBMR = (int)Math.round((655 + (4.3*weight) + (4.7*height) - (4.7*age))/230);
		}
		
		System.out.print("Number of chocolate bars per day needed to maintain your current weight: " + chocolateBMR);
	}
}
**/

/*
 * Question 3
 *
 * There is no code as the palindrome problem has been written in java already.
 **/
 
/*
 * Question 4
 *
 * Write a program that takes the date in the following format: dd/mm/yyyy and outputs the date in full text,
 * or "invalid format" if the date is invalid.
 **/

import java.util.Scanner;

public class Practical11 {
	public static void main(String[] args) {
		String shortDate;
		String[] date;
		int[] intDate = new int[3];
		boolean invalid = false;
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter the date in the form dd/mm/yyyy: ");
		shortDate = s.nextLine();
		
		date = shortDate.split("/");
		shortDate = "";
		
		for(int i=0; i<3; i++) {
			intDate[i] = Integer.parseInt(date[i]);
		}
		
		switch (date[1]) {
			case "01":
				shortDate += "January ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "02":
				shortDate += "February ";
				if(0 < intDate[0] && (intDate[0] < 30 && intDate[2]%4 == 0) || intDate[0] < 29) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "03":
				shortDate += "March ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "04":
				shortDate += "April ";
				if(0 < intDate[0] && intDate[0] < 30) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "05":
				shortDate += "May ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "06":
				shortDate += "June ";
				if(0 < intDate[0] && intDate[0] < 31) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "07":
				shortDate += "July ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "08":
				shortDate += "August ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "09":
				shortDate += "September ";
				if(0 < intDate[0] && intDate[0] < 31) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "10":
				shortDate += "October ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "11":
				shortDate += "November ";
				if(0 < intDate[0] && intDate[0] < 31) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			case "12":
				shortDate += "December ";
				if(0 < intDate[0] && intDate[0] < 32) {
					shortDate += date[0];
				} else {
					invalid = true;
				}
				break;
			default:
				invalid = true;
		}
		
		if(intDate[0] == 1 || intDate[0] == 21 || intDate[0] == 31) {
			shortDate += "st ";
		} else if(intDate[0] == 2 || intDate[0] == 22) {
			shortDate += "nd ";
		} else if(intDate[0] == 3 || intDate[0] == 23) {
			shortDate += "rd ";
		} else {
			shortDate += "th ";
		}
		
		shortDate += date[2];
		
		if(invalid) {
			System.out.println("Date is invalid");
		} else {
			System.out.println(shortDate);
		}
	}
}