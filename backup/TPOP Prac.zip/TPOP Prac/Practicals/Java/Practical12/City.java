package Practical12;

public class City {
	private String name, country, state;
	private int timeZone;
	private double[] coords;
	
	public City() {
		this("Default", "Default", "Default", 0, 0.0, 0.0);
	}
	
	public City(String name, String country, String state, int timeZone, double longitude, double latitude) {
		this.name = name;
		this.country = country;
		this.state = state;
		this.timeZone = timeZone;
		this.coords = new double[2];
		this.coords[0] = longitude;
		this.coords[1] = latitude;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getCountry() {
		return this.country;
	}
	
	public String getState() {
		return this.state;
	}
	
	public int getTimeZone() {
		return this.timeZone;
	}
	
	public double[] getCoords() {
		return this.coords;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public void setTimeZone(int timeZone) {
		this.timeZone = timeZone;
	}
	
	public void setCoords(double[] coords) {
		this.coords[0] = coords[0];
		this.coords[1] = coords[1];
	}
	
	public String toString() {
		return "City <Name: " + this.name + ", Country: " + this.country + ", State: " + this.state + ", Timezone: " + this.timeZone + ", Coordinates: (" + this.coords[0] + ", " + this.coords[1] + ")>";
	}
	
	public boolean equals(Object object) {
		if(object instanceof City && ((City)object).toString().equals(this.toString())) {
			return true;
		} else {
			return false;
		}
	}
}