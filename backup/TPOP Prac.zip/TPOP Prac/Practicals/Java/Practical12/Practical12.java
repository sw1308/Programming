package Practical12;

public class Practical12 {
	public static void main(String[] args) {
		City city1 = new City();
		City city2 = new City("York", "England", "Yorkshire", 0, 0.0, 0.0);
		City city3 = new City("York", "England", "Yorkshire", 0, 0.0, 0.0);
		
		System.out.println(city1.toString());
		System.out.println(city2.getCoords()[0]);
		System.out.println(city2.getCoords()[1]);
		System.out.println(city3.equals(city2));
		city3.setCountry("UK");
		System.out.println(city2.equals(city3));
	}
}