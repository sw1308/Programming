package Practical12;

public class WeightedGraph {
	public WeightedGraph() {
		;
	}
}