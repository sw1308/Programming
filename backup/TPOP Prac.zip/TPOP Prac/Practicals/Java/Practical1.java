/**
 * Question 2
 *
 * Write a block of code that takes the sentence: "All work and no play makes Jack a dull boy", stores each
 * word in a variable and prints out the sentence in one line.
 */

public class Practical1 {	
	public static void main(String[] args) {
		String a, b, c, d, e, f, g, h, i, j;
		
		a = "All ";
		b = "work ";
		c = "and ";
		d = "no ";
		e = "play ";
		f = "makes ";
		g = "Jack ";
		h = "a ";
		i = "dull ";
		j = "boy.";
		
		System.out.printf(a + b + c + d + e + f + g + h + i + j);
	}
}