package Practical8;
import java.util.Scanner;

public class Practical8 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Row evenRow, oddRow;
		int dimension = 0;
		boolean odd = true;
		String endString = "+";
		
		System.out.print("Enter the dimension of the chessboard: ");
		dimension = s.nextInt();
		
		oddRow = new Row(true, dimension);
		evenRow = new Row(false, dimension);
		
		for(int j=0; j<dimension; j++) {
			endString = endString + "-";
		}
		
		endString = endString + "+";
		System.out.println(endString);
		
		for(int i=0; i<dimension; i++) {
			if(odd == true) {
				System.out.println(oddRow.toString());
				odd = false;
			} else {
				System.out.println(evenRow.toString());
				odd = true;
			}
		}
		
		System.out.println(endString);
	}
}