package Practical8;

public class Row {
  private boolean oddRow;
  private int dimension;
  private String rowText;
  
  public Row(boolean oddRow, int dimension) {
    this.oddRow = oddRow;
    this.dimension = dimension;
    this.rowText = "|";
    
    for(int i=0; i<dimension; i++) {
      if(this.oddRow == true) {
        this.rowText += "#";
        this.oddRow = false;
      } else {
        this.rowText += " ";
        this.oddRow = true;
      }
    }
    
    this.rowText += "|";
  }
  
  public String toString() {
    return this.rowText;
  }
}