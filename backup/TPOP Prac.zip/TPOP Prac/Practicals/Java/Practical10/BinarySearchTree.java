package Practical10;

public class BinarySearchTree {
	private Node root;
	
	private class Node {
		private int key;
		private String data;
		private Node left, right;
		
		private Node(int key, String data) {
			this.key = key;
			this.data = data;
			this.left = null;
			this.right = null;
		}
		
		private String getInfo() {
			return "<" + this.getKey() + " : " + this.getData() + ">";
		}
		
		private int getKey() {
			return this.key;
		}
		
		private String getData() {
			return this.data;
		}
		
		private Node getLeft() {
			return this.left;
		}
		
		private Node getRight() {
			return this.right;
		}
		
		private void setData(String data) {
			this.data = data;
		}
		
		private void setLeft(Node left) {
			this.left = left;
		}
		
		private void setRight(Node right) {
			this.right = right;
		}
		
		private boolean isLeaf() {
			if(this.left == null && this.right == null) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	public BinarySearchTree() {
		this(null);
	}
	
	public BinarySearchTree(Node rootNode) {
		this.root = rootNode;
	}
	
	public boolean isEmpty() {
		if(this.root == null) {
			return true;
		} else {
			return false;
		}
	}
	
	public BinarySearchTree getLeftTree() {
		if(this.isEmpty()) {
			return null;
		} else {
			return new BinarySearchTree(this.root.getLeft());
		}
	}
	
	public BinarySearchTree getRightTree() {
		if(this.isEmpty()) {
			return null;
		} else {
			return new BinarySearchTree(this.root.getRight());
		}
	}
	
	public boolean hasLeftBranch() {
		if(this.isEmpty()) {
			return false;
		} else if(this.root.left == null) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean hasRightBranch() {
		if(this.isEmpty()) {
			return false;
		} else if(this.root.right == null) {
			return false;
		} else {
			return true;
		}
	}
	
	public int getRootKey() {
		if(this.isEmpty()) {
			return -1;
		} else {
			return this.root.key;
		}
	}
	
	public String getRootData() {
		if(this.isEmpty()) {
			return null;
		} else {
			return this.root.data;
		}
	}
	
	public void setLeftBranch(BinarySearchTree bst) {
		if(this.isEmpty()) {
			System.out.println("Tree is empty, no left branch was set.");
		} else {
			this.root.left = bst.root;
		}
	}
	
	public void setRightBranch(BinarySearchTree bst) {
		if(this.isEmpty()) {
			System.out.println("Tree is empty, no left branch was set.");
		} else {
			this.root.right = bst.root;
		}
	}
	
	public void insertIterative(int key, String data) {
		Node currentNode = null;
		boolean loopCondition = true;
		
		if(this.isEmpty()) {
			this.root = new Node(key, data);
		} else {
			currentNode = this.root;
			while(loopCondition == true) {
				if(currentNode.getKey() == key) {
					currentNode.setData(data);
					loopCondition = false;
				} else if(currentNode.getKey() > key) {
					if(currentNode.getLeft() == null) {
						currentNode.setLeft(new Node(key, data));
						loopCondition = false;
					} else {
						currentNode = currentNode.getLeft();
					}
				} else {
					if(currentNode.getRight() == null) {
						currentNode.setRight(new Node(key, data));
						loopCondition = false;
					} else {
						currentNode = currentNode.getRight();
					}
				}
			}
		}
	}
	
	public String printInOrder() {
		String treeString = "";
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return treeString;
		} else if(this.root.isLeaf()) {
			return treeString = this.root.getInfo() + ", ";
		}
		
		currentTree = this.getLeftTree();
		treeString = currentTree.printInOrder();
		treeString += this.root.getInfo() + ", ";
		currentTree = this.getRightTree();
		treeString += currentTree.printInOrder();
		
		return treeString;
	}
	
	public void insert(int key, String data) {
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			this.root = new Node(key, data);
			return;
		}
		
		int rootKey = this.root.getKey();
		
		if(rootKey == key) {
			this.root.setData(data);
		} else if(rootKey > key) {
			if(this.root.getLeft() == null) {
				this.root.setLeft(new Node(key, data));
			} else {
				currentTree = this.getLeftTree();
				currentTree.insert(key, data);
			}
		} else {
			if(this.root.getRight() == null) {
				this.root.setRight(new Node(key, data));
			} else {
				currentTree = this.getRightTree();
				currentTree.insert(key, data);
			}
		}
	}
	
	public String get(int key) {
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return null;
		}
		
		int rootKey = this.root.getKey();
		
		if(rootKey == key) {
			return this.root.getData();
		} else if(rootKey > key) {
			if(this.root.getLeft() == null) {
				return null;
			} else {
				currentTree = this.getLeftTree();
				return currentTree.get(key);
			}
		} else {
			if(this.root.getRight() == null) {
				return null;
			} else {
				currentTree = this.getRightTree();
				return currentTree.get(key);
			}
		}
	}
	
	public boolean hasKey(int key) {
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return false;
		}
		
		int rootKey = this.root.getKey();
		
		if(rootKey == key) {
			return true;
		} else if(rootKey > key) {
			if(this.root.getLeft() == null) {
				return false;
			} else {
				currentTree = this.getLeftTree();
				return currentTree.hasKey(key);
			}
		} else {
			if(this.root.getRight() == null) {
				return false;
			} else {
				currentTree = this.getRightTree();
				return currentTree.hasKey(key);
			}
		}
	}
	
	public boolean contains(String data) {
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return false;
		} else if(this.root.getData() == data) {
			return true;
		} else if(this.getLeftTree().contains(data) || this.getRightTree().contains(data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public int getSize() {
		if(this.isEmpty()) {
			return 0;
		} else if(this.root.isLeaf()) {
			return 1;
		} else {
			return this.getLeftTree().getSize() + this.getRightTree().getSize() + 1;
		}
	}
	
	public int[] keys() {
		int[] keys = new int[this.getSize()];
		int position = 0;
		
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return keys;
		} else if(this.root.isLeaf()) {
			keys[position] = this.root.getKey();
			position++;
			return keys;
		}
		
		currentTree = this.getLeftTree();
		for(int item : currentTree.keys()) {
			keys[position] = item;
			position++;	
		}
		
		keys[position] = this.root.getKey();
		position++;
		
		currentTree = this.getRightTree();
		for(int item : currentTree.keys()) {
			keys[position] = item;
			position++;
		}
		
		return keys;
	}
	
	public String[] values() {
		String[] values = new String[this.getSize()];
		int position = 0;
		
		BinarySearchTree currentTree = null;
		
		if(this.isEmpty()) {
			return values;
		} else if(this.root.isLeaf()) {
			values[position] = this.root.getData();
			position++;
			return values;
		}
		
		currentTree = this.getLeftTree();
		for(String item : currentTree.values()) {
			values[position] = item;
			position++;	
		}
		
		values[position] = this.root.getData();
		position++;
		
		currentTree = this.getRightTree();
		for(String item : currentTree.values()) {
			values[position] = item;
			position++;
		}
		
		return values;
	}
}