/*
 * Question 1 + 2
 *
 * Write a function that can calculate whether a number "a" is a power of another number "b"
 * Write another function that can calculate the nth number of the Fibonacci sequence
 **/

/*
package Practical10;
import java.util.Scanner;

public class Practical10 {
	public static void main(String[] args) {
		int a, b, n;
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter the first number: ");
		a = s.nextInt();
		System.out.print("Enter the second number: ");
		b = s.nextInt();
		
		System.out.println("Is " + a + " a factor of " + b + ": " + is_power(a, b));
		
		System.out.print("\n\n\nEnter a position of the Fibonacci sequence: ");
		n = s.nextInt();
		
		System.out.println("Fibonacci number " + n + ": " + fibonacci(n));
	}
	
	public static boolean is_power(int a, int b) {
		if(a == b) {
			return true;
		} else if(a%b == 0) {
			if(is_power(a/b, b)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public static int fibonacci(int n) {
		if(n == 0) {
			return 0;
		} else if(n == 1) {
			return 1;
		} else {
			return fibonacci(n-1) + fibonacci(n-2);
		}
	}
}
*/

/*
 * Question 3
 *
 * Edit the Binary Search Tree to perform several other functions (all functions under insertIterative)
 **/
 
package Practical10;
import java.util.Arrays;

public class Practical10 {
	public static void main(String[] args) {
		BinarySearchTree bst = new BinarySearchTree();
		bst.insert(10, "ten");
		bst.insert(15, "fifteen");
		bst.insert(5, "five");
		bst.insert(11, "eleven");
		bst.insert(11, "onze");
		bst.insert(9, "nine");
		bst.insert(3, "three");
		bst.insert(2, "two");
		bst.insert(6, "six");
		System.out.println("Tree: [" + bst.printInOrder() + "]");
		System.out.println(bst.get(6));
		System.out.println(bst.get(7));
		System.out.println(bst.get(11));
		System.out.println(bst.contains("six"));
		System.out.println(bst.contains("seven"));
		System.out.println(bst.contains("onze"));
		System.out.println("Size: " + bst.getSize());
		System.out.println(Arrays.toString(bst.keys()));
		System.out.println(Arrays.toString(bst.values()));
	}
}