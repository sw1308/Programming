/**
 * Question 1
 *
 * Write a block of code that takes three numbers as an input from the user and outputs the greatest value
 * of the three.
 */
 
import java.util.Scanner;

public class Practical2 {
	public static void main(String[] args) {
		int number = 0;
		int greatest = 0;
		Scanner s = new Scanner(System.in);
		
		for(int i=0; i<3; i++) {
			System.out.print("Next number: ");
			number = s.nextInt();
			if(number > greatest) {
				greatest = number;
			}
		}
		
		System.out.println("Greatest: " + greatest);
	}
}