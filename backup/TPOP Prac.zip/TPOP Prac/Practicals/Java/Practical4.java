/**
 * Question 1
 *
 * Write a function to return the sum of a list of numbers.
 */
 
/**

import java.util.Scanner;
 
public class Practical4 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size;
		
		System.out.print("Enter size of the list of numbers: ");
		size = s.nextInt();
		
		int[] numbers = new int[size];
		
		for(int i=0; i<size; i++) {
			System.out.print("Next number: ");
			numbers[i] = s.nextInt();
		}
		
		System.out.println("Total: " + sumList(numbers, size));
	}
	
	public static int sumList(int[] numbers, int size) {
		int total = 0;
		
		for(int i=0; i<size; i++) {
			total = total + numbers[i];
		}
		
		return total;
	}
}
*/

/**
 * Question 2
 *
 * Write a function that takes a list of numbers and returns a list of the same numbers squared.
 */
 
/**
import java.util.Scanner;
import java.util.Arrays;
 
 public class Practical4 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size;
		
		System.out.print("Enter the size of the list of numbers: ");
		size = s.nextInt();
		int[] numbers = new int[size];
		
		for(int i=0; i<size; i++) {
			System.out.print("Next number: ");
			numbers[i] = s.nextInt();
		}
		
		System.out.println("Squares: " + squareEach(numbers, size));
	}
	
	public static String squareEach(int[] nums, int size) {
		int[] squareList = new int[size];
		int i = 0;
		
		for(int item : nums) {
			squareList[i] = item*item;
			i++;
		}
		
		return Arrays.toString(squareList);
	}
 }
 */
 
/**
 * Question 3
 *
 * Write a function that converts a string of numbers separated by a space into a list of numbers.
 */

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
 
public class Practical4 {
    public static void main(String[] args) {
      String inputString;
      Scanner s = new Scanner(System.in);
      
      System.out.print("Enter a string of numbers separated by spaces: ");
      inputString = s.nextLine();
      
      System.out.println("List of numbers: " + toNumbers(inputString));
    }
    
    public static String toNumbers(String strList) {
      return Arrays.toString(strList.split(" "));
    }
}