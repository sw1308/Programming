package Practical6;

public class Practical6 {
	public static void main(String[] args) {
		LinkedQueue cineQueue = new LinkedQueue();
		LinkedQueue reverseQueue = new LinkedQueue();
		
		System.out.println(cineQueue.toString());
		
		cineQueue.enQueue(1);
		cineQueue.enQueue(2);
		cineQueue.enQueue(3);
		cineQueue.enQueue(4);
		cineQueue.enQueue(5);
		
		System.out.println(cineQueue.toString());
		
		reverseQueue = cineQueue.reverse();
		cineQueue.enQueue(6);
		cineQueue.concatQueue(reverseQueue);
		
		System.out.println(cineQueue.toString());
		System.out.println(cineQueue.deQueue());
		System.out.println(cineQueue.toString());
	}
}