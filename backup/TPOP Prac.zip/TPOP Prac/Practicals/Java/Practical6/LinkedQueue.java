package Practical6;

public class LinkedQueue {
	Node head;
	Node tail;
	int size;
	
	private class Node {
		int datum;
		Node next;
		
		private Node(int datum, Node nextNode) {
			this.datum = datum;
			this.next = nextNode;
		}
	}
	
	public LinkedQueue() {
		this.head = null;
		this.tail = null;
		this.size = 0;
	}
	
	public void enQueue(int datum) {
		Node newNode = new LinkedQueue.Node(datum, null);
		
		if(this.size == 0) {
			this.head = newNode;
			this.tail = newNode;
		} else {
			Node tailNode = this.tail;
			tailNode.next = newNode;
			this.tail = newNode;
		}
		
		this.size ++;
	}
	
	public String toString() {
		Node currentNode = this.head;
		String returnString;
		
		returnString = "Queue: <";
		
		while(currentNode!= null) {
			if(currentNode.next != null) {
				returnString += currentNode.datum + ", ";
			} else {
				returnString += currentNode.datum;
			}
			
			currentNode = currentNode.next;
		}
		
		returnString += ">";
		return returnString;
	}
	
	public Node getHead() {
		return this.head;
	}
	
	public Node getTail() {
		return this.tail;
	}
	
	public int getSize() {
		return this.size;
	}
	
	public int deQueue() {
		Node head = this.head;
		this.head = head.next;
		return head.datum;
	}
	
	public void concatQueue(LinkedQueue queue) {
		this.tail.next = queue.getHead();
	}
	
	public LinkedQueue reverse() {
		LinkedQueue reverseQueue = new LinkedQueue();
		int[] queueArray = new int[this.getSize()];
		Node currentNode = this.head;
		int i = 0;
		
		while(currentNode != null) {
			queueArray[i] = currentNode.datum;
			i ++;
			currentNode = currentNode.next;
		}
		
		for(i = queueArray.length - 1; i>=0; i--) {
			reverseQueue.enQueue(queueArray[i]);
		}
		
		return reverseQueue;
	}
}