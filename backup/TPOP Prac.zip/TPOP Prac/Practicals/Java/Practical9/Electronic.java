package Practical9;
import java.lang.Math;

public class Electronic extends Item {
	private int warranty;
	private String brand;
	
	public Electronic(int barCode, int numberOfUnits, double price, double VAT, int warranty, String brand) {
		this.barCode = barCode;
		this.numberOfUnits = numberOfUnits;
		this.price = price;
		this.VAT = VAT;
		this.warranty = warranty;
		this.brand = brand;
	}
	
	public int getWarranty() {
	  return this.warranty;
	}
	
	public String getBrand() {
	  return this.brand;
	}
	
	public void setWarranty(int warranty) {
	  this.warranty = warranty;
	}
	
	public void setBrand(String brand) {
	  this.brand = brand;
	}
	
	public String toString() {
	  String itemString;
	  double price;
	  
	  price = this.price;
	  price += this.price*this.VAT;
	  price = (Math.round(price * 100))/100.0;
	  
	  itemString = this.brand + ": " + price;
	  
	  return itemString;
	}
}