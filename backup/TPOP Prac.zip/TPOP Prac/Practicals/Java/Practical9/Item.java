package Practical9;
import java.lang.Math;

public abstract class Item {
	protected int barCode, numberOfUnits;
	protected double price, VAT;
	
	public int getBarCode() {
		return this.barCode;
	}
	
	public int getNumberOfUnits() {
		return this.numberOfUnits;
	}
	
	public double getPrice() {
    double price;
    
    price = this.price;
    price += this.price*this.VAT;
	price = (Math.round(price * 100))/100.0;

	return price;
	}
	
	public double getVAT() {
		return this.VAT;
	}
	
	public void setBarCode(int barCode) {
		this.barCode = barCode;
	}
	
	public void setNumberOfUnits(int numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setVAT(double VAT) {
		this.VAT = VAT;
	}
}