package Practical9;
import java.util.*;
import java.lang.Math;

public class Basket {
  List<Item> items;
  
  public Basket() {
    this.items = new ArrayList<Item>();
  }
  
  public void addItem(Item item) {
    this.items.add(item);
  }
  
  public void removeItem(Item item) {
    this.items.remove(item);
  }
  
  public String calcPrice() {
    double total = 0;
    double price;
    
    for(Item item : items) {
      price = item.price;
      price += item.price*item.VAT;
	  price = (Math.round(price * 100))/100.0;
      total += price;
    }
    
    return "Total: " + total;
  }
  
  public String toString() {
    String itemString = "Items: ";
    
    for(Item item : items) {
      itemString += item.toString();
      itemString += ", ";
    }
    
    return itemString;
  }
}