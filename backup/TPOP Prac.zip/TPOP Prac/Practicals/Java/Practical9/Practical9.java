package Practical9;

public class Practical9 {
  public static void main(String[] args) {
    Basket shoppingBasket = new Basket();
    Clothing jeans = new Clothing(12345678, 1, 14.99, 0.15, 10, "Jeans");
    Clothing shirt = new Clothing(12345679, 2, 13.99, 0.15, 12, "Shirt");
    Clothing shoes1 = new Clothing(12345680, 2, 24.99, 0.15, 13, "Large Shoes");
    Clothing shoes2 = new Clothing(12345680, 2, 22.99, 0.15, 7, "Medium Shoes");
    Electronic toaster1 = new Electronic(22345678, 1, 29.99, 0.20, 3, "ToastyMax Toaster");
    Electronic toaster2 = new Electronic(22345679, 1, 19.99, 0.20, 3, "Value Toaster");
    Electronic calculator = new Electronic(22345680, 1, 12.99, 0.20, 5, "Scientific Calculator");
    
    System.out.println(shoppingBasket.toString());
    
    shoppingBasket.addItem(jeans);
    shoppingBasket.addItem(shirt);
    shoppingBasket.addItem(toaster1);
    
    System.out.println(shoppingBasket.calcPrice());
    System.out.println(shoppingBasket.toString());
    
    shoppingBasket.removeItem(shirt);
    shoppingBasket.removeItem(toaster1);
    shoppingBasket.addItem(toaster2);
    shoppingBasket.addItem(shoes2);
    shoppingBasket.addItem(calculator);
    
    System.out.println(shoppingBasket.calcPrice());
    System.out.println(shoppingBasket.toString());
  }
}