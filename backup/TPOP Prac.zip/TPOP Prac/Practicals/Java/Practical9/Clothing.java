package Practical9;
import java.lang.Math;

public class Clothing extends Item {
	private int size;
	private String type;
	
	public Clothing(int barCode, int numberOfUnits, double price, double VAT, int size, String type) {
		this.barCode = barCode;
		this.numberOfUnits = numberOfUnits;
		this.price = price;
		this.VAT = VAT;
		this.size = size;
		this.type = type;
	}
	
	public int getSize() {
	  return this.size;
	}
	
	public String getType() {
	  return this.type;
	}
	
	public void setSize(int size) {
	  this.size = size;
	}
	
	public void setType(String type) {
	  this.type = type;
	}
	
	public String toString() {
	  String itemString;
	  double price;
	  
	  price = this.price;
	  price += this.price*this.VAT;
	  price = (Math.round(price * 100))/100.0;
	  
	  itemString = this.type + ": " + price;
	  
	  return itemString;
	}
}