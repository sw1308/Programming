/**
 * Question 1
 *
 * Write a block of code that takes a string as an input and outputs the ascii value of each character
 * in the string added together.
 */

/**
import java.util.Scanner;

public class Practical3 {
	public static void main(String[] args) {
		int total = 0;
		String inputString;
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter a string: ");
		inputString = s.nextLine();
		
		for(char letter: inputString.toCharArray()) {
			total = total + (int)letter;
		}
		
		System.out.println(total);
	}
}
*/

/**
 * Question 2
 *
 * Write a block of code that takes a string as an input and outputs whether the string is a palindrome or not.
 */

/**
import java.util.Scanner;
import java.io.*;

public class Practical3 {
	public static void main(String[] args) {
		String inputString, inputStringReverse;
		boolean isPalindrome = false;
		Scanner s = new Scanner(System.in);
		
		System.out.print("Enter a string: ");
		inputString = s.nextLine().toLowerCase();
		inputStringReverse = new StringBuilder(inputString).reverse().toString();
		
		if(inputString.equals(inputStringReverse)) {
			isPalindrome = true;
		}
		
		System.out.println("Palindrome? " + isPalindrome);
	}
}
*/

/**
 * Question 3
 *
 * Write a block of code that uses arrays to represent vectors and can perform two basic vector operations,
 * addition and calculating scalar products.
 */
 
 /**
 import java.util.Scanner;
 import java.util.Arrays;
 
 public class Practical3 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int product;
		int size;
		
		System.out.print("Enter the dimension of the vectors: ");
		size = s.nextInt();
		System.out.print("Enter the product for scalar calculations: ");
		product = s.nextInt();
		
		int[] vector1 = new int[size];
		int[] vector2 = new int[size];
		int[] vectorResult = new int[size];
		
		for(int i=0; i<size; i++) {
			System.out.print("Enter the number in position " + i + ": ");
			vector1[i] = s.nextInt();
		}
		
		for(int i=0; i<size; i++) {
			System.out.print("Enter the number in position " + i + ": ");
			vector2[i] = s.nextInt();
		}
		
		for(int i=0; i<size; i++) {
			vectorResult[i] = 0;
		}
		
		for(int i=0; i<size; i++) {
			vectorResult[i] = vector1[i] * product;
		}
		
		System.out.println("Scalar Product: " + Arrays.toString(vectorResult));
		
		for(int i=0; i<size; i++) {
			vectorResult[i] = vector1[i] + vector2[i];
		}
		
		System.out.println("Addition: " + Arrays.toString(vectorResult));
	}
 }
 */
 
 /**
  * Question 4
  *
  * Write a block of code that prints a table of stone to kilogram conversions.
  */
  

import java.util.Scanner;
import java.lang.Math;
  
public class Practical3 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = 0;
		int stone = 0;
		int pound = 0;
		double kilogram = 0.0;
		String line = "|stone/pound|";
		
		System.out.print("Enter the size of the table: ");
		size = s.nextInt();
		
		for(int i=0; i<size; i++) {
			line = line + "    " + pound + "|";
			pound ++;
		}
		
		System.out.println(line);
		line = "";
		
		for(int i=0; i<size; i++) {
			line = "|          " + stone + "|";
			pound = 0;
			
			for(int j=0; j<size; j++) {
				kilogram = (stone * 6.35) + (pound * 0.45);
				if(kilogram > 10) {
					line = line + " " + (Math.round(kilogram * 10.0)/10.0) + "|";
				} else if(kilogram > 100) {
					line = line + (Math.round(kilogram * 10.0)/10.0) + "|";
				} else {
					line = line + "  " + (Math.round(kilogram * 10.0)/10.0) + "|";
				}
				pound ++;
			}
			
			stone ++;
			System.out.println(line);
		}
	}
}