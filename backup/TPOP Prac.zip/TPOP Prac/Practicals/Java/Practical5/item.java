package Practical5;

public class item {
	private String title, author, mediaType;
	private boolean status;
	int memberID;
	
	public item(String title, String author, String mediaType) {
		this.title = title;
		this.author = author;
		this.mediaType = mediaType;
		this.status = false;
		this.memberID = -1;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public String getAuthor() {
		return this.author;
	}
	
	public String getMediaType() {
		return this.mediaType;
	}
	
	public boolean getStatus() {
		return this.status;
	}
	
	public int getMemberID() {
		return this.memberID;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}
	
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public void setMemberID(int memberID) {
		this.memberID = memberID;
	}
	
	public String toString() {
		String taken;
		
		if(this.status == false) {
			taken = "Not Taken";
		} else {
			taken = "Taken";
		}
		
		return "Title: " + this.title + "    |Author: " + this.author + "    |Media Type: " + this.mediaType + "    |Status: " + taken + "    |ID of Renter: " + this.memberID;
	}
}