package Practical5;
import java.util.ArrayList;
import java.util.List;

public class member {
	private String firstName, surName, postCode, listString;
	public List<Integer> itemList;
	
	public member(String firstName, String surName, String postCode) {
		this.firstName = firstName;
		this.surName = surName;
		this.postCode = postCode;
		this.itemList = new ArrayList<>();
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getSurName() {
		return this.surName;
	}
	
	public String getPostCode() {
		return this.postCode;
	}
	
	public String getItemList() {
		for(int i=0; i<this.itemList.size(); i++) {
			listString += itemList.get(i);
		}
		
		return listString;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setSurName(String surName) {
		this.surName = surName;
	}
	
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	
	public void appendItem(int itemID) {
		this.itemList.add(itemID);
	}
	
	public void removeItem(int itemID) {
		this.itemList.remove(itemList.indexOf(itemID));
	}
	
	public String toString() {
		listString = "";
		
		for(int i=0; i<this.itemList.size(); i++) {
			listString += itemList.get(i);
		}
		
		return "Name: " + this.firstName + " " + this.surName + "    |Postcode: " + this.postCode + "    |Rented Items: " + listString;
	}
}