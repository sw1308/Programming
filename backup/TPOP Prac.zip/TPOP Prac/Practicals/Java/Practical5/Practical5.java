package Practical5;
import java.util.*;

public class Practical5 {
	public static Map<Integer, member> memberLibrary = new HashMap<Integer, member>();
	public static Map<Integer, item> itemLibrary = new HashMap<Integer, item>();
	public static String listString;

	public static void main(String[] args) {		
		member member1 = new member("Jack", "Butcher", "YO10 5ES");
		member member2 = new member("James", "Hornsby", "YO10 5ES");
		member member3 = new member("Liam", "Franks", "YO10 5ES");
		
		item item1 = new item("Title 1", "Author 1", "CD");
		item item2 = new item("Title 2", "Author 2", "DVD");
		item item3 = new item("Title 3", "Author 3", "Book");
		
		memberLibrary.put(0, member1);
		memberLibrary.put(1, member2);
		memberLibrary.put(2, member3);
		
		itemLibrary.put(0, item1);
		itemLibrary.put(1, item2);
		itemLibrary.put(2, item3);
		
		rentItem(0, 0);
		rentItem(0, 1);
		rentItem(1, 2);
		
		printMembers();
		printItems();
		
		returnItem(0, 0);
		rentItem(1, 0);
		
		printMembers();
		printItems();
		
		returnItem(0, 1);
		returnItem(1, 0);
		returnItem(1, 2);
		
		printMembers();
		printItems();
	}
	
	public static void rentItem(int memberID, int itemID) {
		member tempMember = memberLibrary.get(memberID);
		item tempItem = itemLibrary.get(itemID);
		
		tempMember.appendItem(itemID);
		tempItem.setStatus(true);
		tempItem.setMemberID(memberID);
		
		memberLibrary.put(memberID, tempMember);
		itemLibrary.put(itemID, tempItem);
	}
	
	public static void returnItem(int memberID, int itemID) {
		member tempMember = memberLibrary.get(memberID);
		item tempItem = itemLibrary.get(itemID);
		
		tempMember.removeItem(itemID);
		tempItem.setStatus(false);
		tempItem.setMemberID(-1);
		
		memberLibrary.put(memberID, tempMember);
		itemLibrary.put(itemID, tempItem);
	}
	
	public static void printMembers() {
		listString = "";
		
		for(int i=0; i<memberLibrary.size(); i++) {
			listString += memberLibrary.get(i).toString();
			listString += "\n";
		}
		
		listString += "\n\n";
		
		System.out.println("Members:\n" + listString);
	}
	
	public static void printItems() {
		listString = "";
		
		for(int i=0; i<itemLibrary.size(); i++) {
			listString += itemLibrary.get(i).toString();
			listString += "\n";
		}
		
		listString += "\n\n";
		
		System.out.println("Items:\n" + listString);
	}
}